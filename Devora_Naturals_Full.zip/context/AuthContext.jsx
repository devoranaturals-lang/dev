"use client";

import { createContext, useContext, useState, useEffect } from "react";
import { supabase, isSupabaseConfigured, registerCustomer, loginCustomerUser } from "../lib/supabase";

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [customerUser, setCustomerUser] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function checkAuth() {
      if (isSupabaseConfigured && supabase) {
        const { data } = await supabase.auth.getSession();
        if (data?.session) {
          setUser(data.session.user);
          setIsAdmin(true);
        }
      } else {
        // Fallback local admin check
        const storedAdmin = localStorage.getItem("devora_admin_session");
        if (storedAdmin === "active") {
          setUser({ email: "admin@devoranaturals.com" });
          setIsAdmin(true);
        }
      }
      
      const storedCustomer = localStorage.getItem("devora_customer_session");
      if (storedCustomer) {
        try {
          setCustomerUser(JSON.parse(storedCustomer));
        } catch (e) {
          console.error(e);
        }
      }
      setLoading(false);
    }
    checkAuth();
  }, []);

  const loginAdmin = async (email, password) => {
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      if (error) throw error;
      setUser(data.user);
      setIsAdmin(true);
      return data.user;
    } else {
      // Demo authentication for local setup
      if (email === "admin@devoranaturals.com" && password === "admin123") {
        const mockUser = { email: "admin@devoranaturals.com" };
        localStorage.setItem("devora_admin_session", "active");
        setUser(mockUser);
        setIsAdmin(true);
        return mockUser;
      } else if (email && password && password.length >= 4) {
        // Accept any temporary test login for demonstration
        const mockUser = { email };
        localStorage.setItem("devora_admin_session", "active");
        setUser(mockUser);
        setIsAdmin(true);
        return mockUser;
      } else {
        throw new Error("Invalid admin credentials");
      }
    }
  };

  const logoutAdmin = async () => {
    if (isSupabaseConfigured && supabase) {
      await supabase.auth.signOut();
    }
    localStorage.removeItem("devora_admin_session");
    setUser(null);
    setIsAdmin(false);
  };

  const loginCustomer = async (email, password) => {
    const customer = await loginCustomerUser(email, password);
    setCustomerUser(customer);
    localStorage.setItem("devora_customer_session", JSON.stringify(customer));
    return customer;
  };

  const registerNewCustomer = async (data) => {
    const customer = await registerCustomer(data);
    setCustomerUser(customer);
    localStorage.setItem("devora_customer_session", JSON.stringify(customer));
    return customer;
  };

  const logoutCustomer = () => {
    setCustomerUser(null);
    localStorage.removeItem("devora_customer_session");
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        customerUser,
        isAdmin,
        loading,
        loginAdmin,
        logoutAdmin,
        loginCustomer,
        registerNewCustomer,
        logoutCustomer,
        setCustomerUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
