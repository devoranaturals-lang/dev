"use client";

import { useState, useEffect } from "react";
import { getOffers } from "../lib/supabase";
import { Sparkles, Percent, Tag, X } from "lucide-react";

export default function OfferBanner() {
  const [activeOffer, setActiveOffer] = useState(null);
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    async function fetchActiveOffer() {
      try {
        const offers = await getOffers();
        const active = offers.find(o => o.isActive);
        if (active) {
          setActiveOffer(active);
        }
      } catch (error) {
        console.error("Failed to load offers", error);
      }
    }
    fetchActiveOffer();
  }, []);

  if (!activeOffer || !isVisible) return null;

  return (
    <div className="bg-gradient-to-r from-brand-900 via-brand-800 to-brand-900 text-white relative shadow-md z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2.5">
        <div className="flex flex-col sm:flex-row items-center justify-center gap-2 sm:gap-4 text-center">
          <div className="flex items-center gap-1.5 text-earth-300">
            {activeOffer.type === 'coupon' || activeOffer.type === 'discount' ? (
              <Percent className="w-4 h-4" />
            ) : (
              <Sparkles className="w-4 h-4" />
            )}
            <span className="text-xs font-bold uppercase tracking-widest">{activeOffer.title}</span>
          </div>
          
          <div className="text-sm font-medium">
            {activeOffer.description}
          </div>

          {activeOffer.discountCode && (
            <div className="flex items-center gap-2 bg-brand-950/40 px-3 py-1 rounded-full border border-brand-700/50">
              <Tag className="w-3.5 h-3.5 text-brand-300" />
              <span className="text-xs font-semibold text-brand-100">Code: <span className="font-mono font-bold text-white">{activeOffer.discountCode}</span></span>
            </div>
          )}
        </div>
      </div>
      <button 
        onClick={() => setIsVisible(false)}
        className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 hover:bg-white/10 rounded-full transition-colors"
      >
        <X className="w-4 h-4 text-brand-300" />
      </button>
    </div>
  );
}
