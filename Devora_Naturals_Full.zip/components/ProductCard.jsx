"use client";

import Image from "next/image";
import Link from "next/link";
import { ShoppingBag, Star, ArrowRight, Check } from "lucide-react";
import { useState } from "react";
import { useCart } from "../context/CartContext";
import { useRouter } from "next/navigation";

export default function ProductCard({ product }) {
  const { addToCart } = useCart();
  const router = useRouter();
  const [added, setAdded] = useState(false);

  const handleAddToCart = (e) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product);
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  };

  const handleBuyNow = (e) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product);
    router.push("/cart");
  };

  return (
    <div className="group bg-white rounded-2xl overflow-hidden border border-emerald-900/10 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col h-full transform hover:-translate-y-1">
      {/* Product Image Container */}
      <div className="relative aspect-square w-full bg-emerald-50/50 overflow-hidden">
        <img
          src={product.image_url || "https://images.unsplash.com/photo-1608248597263-00079e96047c?auto=format&fit=crop&w=600&q=80"}
          alt={product.name}
          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
        />
        
        {/* Category Pill Badge */}
        <div className="absolute top-3 left-3 flex flex-col gap-1 items-start">
          <span className="bg-brand-900/90 text-brand-100 text-[11px] font-semibold px-3 py-1 rounded-full backdrop-blur-md border border-brand-700/50 shadow-sm">
            {product.category}
          </span>
          {product.actual_price && Number(product.actual_price) > Number(product.price) && (
            <span className="bg-red-500/90 text-white text-[10px] font-bold px-2 py-0.5 rounded-md backdrop-blur-md shadow-sm">
              {Math.round(((Number(product.actual_price) - Number(product.price)) / Number(product.actual_price)) * 100)}% OFF
            </span>
          )}
        </div>

        {/* Rating Badge */}
        {product.rating && (
          <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-md text-amber-700 text-xs font-bold px-2.5 py-1 rounded-full shadow-sm flex items-center gap-1">
            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
            <span>{product.rating}</span>
          </div>
        )}
      </div>

      {/* Product Card Details */}
      <div className="p-5 flex flex-col flex-grow justify-between space-y-4">
        <div>
          <Link href={`/products/${product.id}`}>
            <h3 className="text-lg font-bold text-slate-800 group-hover:text-brand-700 transition-colors line-clamp-1">
              {product.name}
            </h3>
          </Link>
          <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
            {product.description}
          </p>
        </div>

        <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
          <div>
            <div className="flex flex-col">
              {product.actual_price && Number(product.actual_price) > Number(product.price) ? (
                <>
                  <span className="text-xs text-slate-500 font-medium">
                    Actual Price: <span className="line-through">₹{Number(product.actual_price).toLocaleString("en-IN")}</span>
                  </span>
                  <span className="text-sm font-bold text-slate-700 mt-0.5">
                    Offer Price: <span className="text-xl font-extrabold text-earth-700">₹{Number(product.price).toLocaleString("en-IN")}</span>
                  </span>
                </>
              ) : (
                <>
                  <span className="text-xs text-slate-500 font-medium">Price</span>
                  <span className="text-xl font-extrabold text-earth-700 mt-0.5">
                    ₹{Number(product.price).toLocaleString("en-IN")}
                  </span>
                </>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleAddToCart}
              className={`p-2.5 rounded-xl transition-all duration-200 flex items-center justify-center ${
                added
                  ? "bg-emerald-600 text-white"
                  : "bg-brand-50 hover:bg-brand-100 text-brand-800 border border-brand-200"
              }`}
              title="Add to Shopping Cart"
            >
              {added ? <Check className="w-4 h-4" /> : <ShoppingBag className="w-4 h-4" />}
            </button>

            <button
              onClick={handleBuyNow}
              className="px-3.5 py-2.5 bg-brand-800 hover:bg-brand-900 text-white text-xs font-bold rounded-xl transition-colors shadow-sm flex items-center gap-1"
            >
              <span>Buy</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
