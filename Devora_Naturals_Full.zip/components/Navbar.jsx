"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { ShoppingBag, Leaf, Menu, X, User } from "lucide-react";
import { useState, useEffect } from "react";
import { useCart } from "../context/CartContext";
import { useAuth } from "../context/AuthContext";

export default function Navbar() {
  const pathname = usePathname();
  const { cartCount } = useCart();
  const [mobileOpen, setMobileOpen] = useState(false);

  // Hide main user nav on admin subpages
  if (pathname?.startsWith("/admin")) {
    return null;
  }

  const [categories, setCategories] = useState([]);

  useEffect(() => {
    import("../lib/supabase").then(async ({ getCategories }) => {
      try {
        const cats = await getCategories();
        if (cats) setCategories(cats);
      } catch (err) {
        console.error("Failed to load categories for navbar", err);
      }
    });
  }, []);

  const navLinks = [
    { name: "Home", href: "/" },
    { name: "All Products", href: "/products" },
    ...categories.map(cat => ({
      name: cat.name,
      href: `/products?category=${encodeURIComponent(cat.name)}`
    })),
    { name: "About Us", href: "/about" },
    { name: "Contact", href: "/contact" },
  ];

  return (
    <header className="sticky top-0 z-40 bg-brand-900/95 backdrop-blur-md border-b border-brand-800 text-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Brand Logo */}
          <Link href="/" className="flex items-center space-x-3 group">
            <div className="p-2.5 bg-gradient-to-br from-brand-600 to-brand-800 rounded-xl shadow-md group-hover:scale-105 transition-transform duration-300">
              <Leaf className="w-6 h-6 text-brand-200" />
            </div>
            <div>
              <span className="text-2xl font-bold tracking-tight bg-gradient-to-r from-white via-brand-100 to-brand-300 bg-clip-text text-transparent">
                Devora Naturals
              </span>
              <span className="block text-[10px] uppercase tracking-widest text-brand-300 font-semibold">
                Pure Organic Botanical
              </span>
            </div>
          </Link>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center space-x-1">
            {navLinks.map((link) => {
              const isActive = pathname === link.href;
              return (
                <Link
                  key={link.name}
                  href={link.href}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                    isActive
                      ? "bg-brand-800 text-earth-200 font-semibold shadow-inner"
                      : "text-brand-100 hover:text-earth-200 hover:bg-brand-800/60"
                  }`}
                >
                  {link.name}
                </Link>
              );
            })}
          </nav>

          {/* Action Buttons: Cart & Admin */}
          <div className="flex items-center space-x-4">
            <Link
              href="/cart"
              className="relative p-2.5 text-brand-100 hover:text-white bg-brand-800/80 hover:bg-brand-800 rounded-xl transition-all duration-200 shadow-sm flex items-center gap-2 px-3.5 border border-brand-700/50"
            >
              <ShoppingBag className="w-5 h-5 text-earth-200" />
              <span className="hidden sm:inline text-xs font-semibold">Cart</span>
              {cartCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-earth-600 text-white text-[11px] font-bold w-5 h-5 rounded-full flex items-center justify-center shadow-md animate-pulse">
                  {cartCount}
                </span>
              )}
            </Link>

            <Link
              href="/account"
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-earth-700 hover:bg-earth-800 text-white rounded-lg transition-colors shadow-sm"
            >
              <User className="w-4 h-4" />
              Account
            </Link>

            {/* Mobile Hamburger Toggle */}
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="lg:hidden p-2 rounded-lg text-brand-100 hover:text-white hover:bg-brand-800"
            >
              {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileOpen && (
        <div className="lg:hidden border-t border-brand-800 bg-brand-900 px-4 pt-3 pb-6 space-y-2 shadow-2xl animate-in slide-in-from-top duration-200">
          {navLinks.map((link) => (
            <Link
              key={link.name}
              href={link.href}
              onClick={() => setMobileOpen(false)}
              className="block px-4 py-2.5 text-base font-medium text-brand-100 hover:text-earth-200 hover:bg-brand-800 rounded-lg"
            >
              {link.name}
            </Link>
          ))}
          <Link
            href="/account"
            onClick={() => setMobileOpen(false)}
            className="block px-4 py-2.5 text-base font-medium text-earth-300 hover:text-white hover:bg-brand-800 rounded-lg border-t border-brand-800 mt-2"
          >
            Customer Account
          </Link>
        </div>
      )}
    </header>
  );
}
