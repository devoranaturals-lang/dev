"use client";

import { useState, useEffect } from "react";
import { getContactDetails, updateContactDetails } from "../../../lib/supabase";
import { Save, Mail, Phone, MapPin, MessageCircle } from "lucide-react";

export default function AdminSettingsPage() {
  const [formData, setFormData] = useState({
    email: "",
    phone: "",
    address: "",
    whatsapp: ""
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState("");

  useEffect(() => {
    async function loadSettings() {
      try {
        setLoading(true);
        const data = await getContactDetails();
        if (data) {
          setFormData({
            email: data.email || "",
            phone: data.phone || "",
            address: data.address || "",
            whatsapp: data.whatsapp || "8608540400"
          });
        }
      } catch (error) {
        console.error("Failed to load settings:", error);
      } finally {
        setLoading(false);
      }
    }
    loadSettings();
  }, []);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      setSaving(true);
      setSuccessMsg("");
      await updateContactDetails(formData);
      setSuccessMsg("Contact details updated successfully!");
      setTimeout(() => setSuccessMsg(""), 3000);
    } catch (error) {
      console.error("Error updating settings:", error);
      alert("Failed to update settings.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <h1 className="text-2xl font-bold text-slate-800">Store Settings</h1>
        <p className="text-sm text-slate-500 mt-1">Manage public contact information and WhatsApp order number.</p>
      </div>

      <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
        {loading ? (
          <p className="text-slate-500 text-sm">Loading settings...</p>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6">
            <h2 className="text-xl font-bold text-slate-900 border-b border-slate-100 pb-4">
              Contact Information
            </h2>
            
            {successMsg && (
              <div className="p-4 bg-green-50 border border-green-200 text-green-700 text-sm font-semibold rounded-2xl">
                {successMsg}
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-2">
                  <Mail className="w-4 h-4 text-brand-600" /> Support Email
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="support@devoranaturals.com"
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-700"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-2">
                  <Phone className="w-4 h-4 text-brand-600" /> Customer Care Phone
                </label>
                <input
                  type="text"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  placeholder="+91 (800) 456-7890"
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-700"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-brand-600" /> Office/Farm Address
                </label>
                <textarea
                  name="address"
                  rows={2}
                  value={formData.address}
                  onChange={handleChange}
                  placeholder="Kerala Botanical Organic Farm, India"
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-700"
                />
              </div>

              <div className="md:col-span-2 pt-4 border-t border-slate-100">
                <h3 className="text-sm font-bold text-slate-800 mb-4">Order Settings</h3>
                <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-2">
                  <MessageCircle className="w-4 h-4 text-emerald-600" /> WhatsApp Order Number (Format: CountryCode + Number)
                </label>
                <input
                  type="text"
                  name="whatsapp"
                  value={formData.whatsapp}
                  onChange={handleChange}
                  placeholder="e.g. 918608540400"
                  className="w-full md:w-1/2 px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
                <p className="text-xs text-slate-500 mt-2">
                  This is the number customers will be redirected to for submitting their orders via WhatsApp. Do not include "+" sign.
                </p>
              </div>
            </div>

            <div className="flex justify-end pt-4 border-t border-slate-100">
              <button
                type="submit"
                disabled={saving}
                className="bg-brand-800 hover:bg-brand-900 disabled:opacity-50 text-white px-8 py-3 rounded-xl text-sm font-bold shadow-md flex items-center gap-2 transition-all"
              >
                <Save className="w-4 h-4" />
                {saving ? "Saving..." : "Save Settings"}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
