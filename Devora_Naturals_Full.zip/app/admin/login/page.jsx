"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "../../../context/AuthContext";
import { Leaf, Lock, Mail, ArrowRight } from "lucide-react";

export default function AdminLoginPage() {
  const router = useRouter();
  const { loginAdmin } = useAuth();

  const [email, setEmail] = useState("admin@devoranaturals.com");
  const [password, setPassword] = useState("admin123");
  const [errorMsg, setErrorMsg] = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      setLoading(true);
      setErrorMsg("");
      await loginAdmin(email, password);
      router.push("/admin");
    } catch (err) {
      console.error(err);
      setErrorMsg(err.message || "Login failed. Please check credentials.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-brand-900 text-white flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-brand-800/90 border border-brand-700/80 p-8 rounded-3xl shadow-2xl backdrop-blur-xl space-y-6">
        {/* Brand Header */}
        <div className="text-center space-y-2">
          <div className="p-3 bg-gradient-to-br from-brand-600 to-brand-700 w-14 h-14 rounded-2xl mx-auto flex items-center justify-center shadow-lg">
            <Leaf className="w-8 h-8 text-brand-200" />
          </div>
          <h1 className="text-2xl font-black text-white pt-2">Admin Portal</h1>
          <p className="text-xs text-brand-200">Devora Naturals Management Console</p>
        </div>

        {errorMsg && (
          <div className="p-3 bg-red-900/60 border border-red-700 text-red-200 text-xs font-semibold rounded-xl text-center">
            {errorMsg}
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-brand-200 mb-1">Admin Email</label>
            <div className="relative">
              <Mail className="w-4 h-4 absolute left-3.5 top-3 text-brand-400" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-brand-900/90 border border-brand-700 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-earth-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-brand-200 mb-1">Password</label>
            <div className="relative">
              <Lock className="w-4 h-4 absolute left-3.5 top-3 text-brand-400" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-brand-900/90 border border-brand-700 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-earth-500"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-earth-600 hover:bg-earth-700 text-white font-bold rounded-xl transition-all shadow-lg flex items-center justify-center gap-2 text-sm"
          >
            <span>{loading ? "Authenticating..." : "Sign In to Dashboard"}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <p className="text-[11px] text-brand-400 text-center">
          Default Demo Credentials: <br />
          <span className="font-mono text-brand-200">admin@devoranaturals.com</span> / <span className="font-mono text-brand-200">admin123</span>
        </p>
      </div>
    </div>
  );
}
