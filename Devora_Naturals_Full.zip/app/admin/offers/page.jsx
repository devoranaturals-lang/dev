"use client";

import { useState, useEffect } from "react";
import { getOffers, addOffer, updateOffer, deleteOffer } from "../../../lib/supabase";
import { Plus, Trash2, Edit2, Tag, Percent, X, Check } from "lucide-react";

export default function AdminOffersPage() {
  const [offers, setOffers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editItem, setEditItem] = useState(null);

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    discountCode: "",
    type: "festival", // coupon, discount, festival
    isActive: true,
  });

  const [submitting, setSubmitting] = useState(false);
  const [statusMsg, setStatusMsg] = useState("");
  const [successMsg, setSuccessMsg] = useState("");

  useEffect(() => {
    fetchOffers();
  }, []);

  async function fetchOffers() {
    try {
      setLoading(true);
      const data = await getOffers();
      setOffers(data || []);
    } catch (error) {
      console.error("Error fetching offers:", error);
    } finally {
      setLoading(false);
    }
  }

  const handleOpenAdd = () => {
    setEditItem(null);
    setFormData({
      title: "",
      description: "",
      discountCode: "",
      type: "festival",
      isActive: true,
    });
    setStatusMsg("");
    setModalOpen(true);
  };

  const handleOpenEdit = (offer) => {
    setEditItem(offer);
    setFormData({
      title: offer.title || "",
      description: offer.description || "",
      discountCode: offer.discountCode || "",
      type: offer.type || "festival",
      isActive: offer.isActive !== undefined ? Boolean(offer.isActive) : true,
    });
    setStatusMsg("");
    setModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.title) return;
    try {
      setSubmitting(true);
      setStatusMsg("");
      
      if (editItem) {
        await updateOffer(editItem.id, formData);
        setSuccessMsg("Offer updated successfully!");
      } else {
        await addOffer(formData);
        setSuccessMsg("Offer created successfully!");
      }
      
      setModalOpen(false);
      setTimeout(() => setSuccessMsg(""), 3000);
      await fetchOffers();
    } catch (error) {
      console.error("Error saving offer:", error);
      setStatusMsg("Failed to save offer. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (id, title) => {
    if (confirm(`Are you sure you want to delete offer "${title || 'this offer'}"?`)) {
      try {
        await deleteOffer(id);
        setSuccessMsg("Offer deleted successfully!");
        setTimeout(() => setSuccessMsg(""), 3000);
        await fetchOffers();
      } catch (error) {
        console.error("Error deleting offer:", error);
        alert("Failed to delete offer.");
      }
    }
  };

  return (
    <div className="space-y-6 max-w-5xl">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900">Offers & Ads</h1>
          <p className="text-xs text-slate-500 mt-1">Manage festival promotions, discount banners, and coupon codes.</p>
        </div>
        <button
          onClick={handleOpenAdd}
          className="flex items-center justify-center gap-2 bg-brand-800 hover:bg-brand-900 text-white px-5 py-2.5 rounded-xl text-xs font-bold transition-all shadow-md"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Offer</span>
        </button>
      </div>

      {successMsg && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-bold rounded-2xl flex items-center gap-2">
          <Check className="w-4 h-4 text-emerald-600" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Add / Edit Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl border border-slate-200 p-6 space-y-6 animate-in fade-in zoom-in duration-150">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-bold text-slate-900 text-base">
                {editItem ? "Edit Offer" : "Add New Offer"}
              </h3>
              <button onClick={() => setModalOpen(false)} className="p-1 rounded-lg text-slate-400 hover:bg-slate-100">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <label className="block font-bold text-slate-700 mb-1">Offer Title *</label>
                  <input
                    type="text"
                    required
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="e.g. Festive Wellness Sale"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-700"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Discount Code (Optional)</label>
                  <input
                    type="text"
                    value={formData.discountCode}
                    onChange={(e) => setFormData({ ...formData, discountCode: e.target.value })}
                    placeholder="e.g. FESTIVE10"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-700 font-mono uppercase"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Offer Type</label>
                  <select
                    value={formData.type}
                    onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-700 font-semibold"
                  >
                    <option value="festival">Festival Offer</option>
                    <option value="coupon">Coupon Code</option>
                    <option value="discount">Discount Ad</option>
                  </select>
                </div>

                <div className="md:col-span-2">
                  <label className="flex items-center gap-2 cursor-pointer p-2.5 bg-slate-50 border border-slate-200 rounded-xl">
                    <input
                      type="checkbox"
                      checked={formData.isActive}
                      onChange={(e) => setFormData({ ...formData, isActive: e.target.checked })}
                      className="w-4 h-4 text-brand-700 rounded border-slate-300"
                    />
                    <span className="text-xs font-bold text-slate-700">Set as Active (Visible across Store)</span>
                  </label>
                </div>

                <div className="md:col-span-2">
                  <label className="block font-bold text-slate-700 mb-1">Short Description *</label>
                  <textarea
                    required
                    rows={2}
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Get 10% off on all Ayurvedic oils and dhoop products."
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-700"
                  />
                </div>
              </div>

              {statusMsg && (
                <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs font-semibold rounded-xl">
                  {statusMsg}
                </div>
              )}

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl text-xs hover:bg-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="bg-brand-800 hover:bg-brand-900 disabled:opacity-50 text-white px-6 py-2 rounded-xl text-xs font-bold shadow-md transition-all"
                >
                  {submitting ? "Saving..." : editItem ? "Update Offer" : "Save Offer"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Offers List */}
      {loading ? (
        <div className="bg-white p-12 rounded-3xl border border-slate-200 text-center text-xs font-semibold text-slate-500">
          Loading offers...
        </div>
      ) : offers.length === 0 ? (
        <div className="bg-white p-12 rounded-3xl border border-slate-200 text-center space-y-3">
          <Tag className="w-12 h-12 text-slate-300 mx-auto" />
          <p className="text-sm font-bold text-slate-700">No offers found.</p>
          <p className="text-xs text-slate-400">Click "Add New Offer" above to create promotional banners or coupons.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {offers.map((offer) => (
            <div
              key={offer.id}
              className={`bg-white rounded-3xl border ${
                offer.isActive ? "border-brand-500 shadow-md" : "border-slate-200 shadow-sm opacity-80"
              } p-6 flex flex-col justify-between space-y-4`}
            >
              <div>
                <div className="flex justify-between items-center mb-3">
                  <div className="flex gap-2 items-center">
                    {offer.type === "coupon" ? (
                      <Percent className="w-4 h-4 text-brand-600" />
                    ) : (
                      <Tag className="w-4 h-4 text-brand-600" />
                    )}
                    <span className="text-[10px] font-extrabold uppercase tracking-wide text-brand-700">
                      {offer.type}
                    </span>
                  </div>
                  <span
                    className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${
                      offer.isActive ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-500"
                    }`}
                  >
                    {offer.isActive ? "ACTIVE" : "INACTIVE"}
                  </span>
                </div>

                <h3 className="text-base font-extrabold text-slate-900 leading-snug">{offer.title}</h3>
                <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">{offer.description}</p>

                {offer.discountCode && (
                  <div className="mt-3 bg-slate-50 border border-dashed border-slate-300 px-3 py-1.5 rounded-xl inline-block">
                    <span className="text-[10px] font-bold text-slate-400">CODE:</span>{" "}
                    <span className="font-mono font-extrabold text-xs text-brand-800">{offer.discountCode}</span>
                  </div>
                )}
              </div>

              {/* Action Buttons: Edit and Delete */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  onClick={() => handleOpenEdit(offer)}
                  className="p-2 bg-blue-50 text-blue-600 hover:bg-blue-100 rounded-xl transition-colors"
                  title="Edit Offer"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(offer.id, offer.title)}
                  className="p-2 bg-red-50 text-red-600 hover:bg-red-100 rounded-xl transition-colors"
                  title="Delete Offer"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
