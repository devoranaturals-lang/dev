"use client";

import { useState, useEffect } from "react";
import { getStorefrontSettings, updateStorefrontSettings } from "../../../lib/supabase";
import { Layout, Save, Image as ImageIcon, Loader2 } from "lucide-react";

export default function AdminStorefrontPage() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState("");
  
  const [form, setForm] = useState({
    heroBgGradientStart: "#064e3b",
    heroBgGradientEnd: "#065f46",
    heroHeading: "",
    heroDescription: "",
    bestsellerEnabled: true,
    bestsellerTitle: "",
    bestsellerSubtitle: "",
    bestsellerImage: "",
    promoBannerEnabled: false,
    promoBannerTitle: "",
    promoBannerSubtitle: "",
    promoBannerImage: ""
  });

  useEffect(() => {
    async function loadSettings() {
      try {
        const data = await getStorefrontSettings();
        if (data) {
          setForm(data);
        }
      } catch (err) {
        console.error("Failed to load storefront settings", err);
      } finally {
        setLoading(false);
      }
    }
    loadSettings();
  }, []);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleImageUpload = (e, fieldName = "bestsellerImage") => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setForm({ ...form, [fieldName]: reader.result });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    setSuccessMsg("");
    try {
      await updateStorefrontSettings(form);
      setSuccessMsg("Storefront updated successfully! View your homepage to see the changes.");
      setTimeout(() => setSuccessMsg(""), 5000);
    } catch (err) {
      console.error(err);
      alert("Failed to update storefront settings.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center p-20 space-y-4">
        <Loader2 className="w-8 h-8 text-brand-700 animate-spin" />
        <p className="text-slate-500 font-medium text-sm">Loading storefront settings...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-4xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900">Storefront Design</h1>
          <p className="text-xs text-slate-500 mt-1">Customize your homepage hero section and featured products.</p>
        </div>
        <button
          onClick={handleSubmit}
          disabled={saving}
          className="px-5 py-2.5 bg-brand-800 hover:bg-brand-900 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-md transition-all disabled:opacity-70"
        >
          {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          <span>Save Changes</span>
        </button>
      </div>

      {successMsg && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-700 p-4 rounded-xl text-sm font-bold shadow-sm">
          {successMsg}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-8">
        
        {/* HERO SECTION CONFIG */}
        <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm space-y-6">
          <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
            <div className="p-2 bg-brand-50 text-brand-700 rounded-lg">
              <Layout className="w-5 h-5" />
            </div>
            <h2 className="text-lg font-bold text-slate-800">Hero Section Details</h2>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Main Heading</label>
              <input
                type="text"
                name="heroHeading"
                value={form.heroHeading || ""}
                onChange={handleChange}
                placeholder="Natural Care For Your Skin..."
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-700"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Sub Description</label>
              <textarea
                name="heroDescription"
                rows={2}
                value={form.heroDescription || ""}
                onChange={handleChange}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-700"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-2">Background Gradient Start</label>
                <div className="flex items-center gap-3">
                  <input
                    type="color"
                    name="heroBgGradientStart"
                    value={form.heroBgGradientStart || "#064e3b"}
                    onChange={handleChange}
                    className="w-12 h-12 rounded cursor-pointer border-0 p-0"
                  />
                  <span className="text-sm font-mono text-slate-500">{form.heroBgGradientStart}</span>
                </div>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-2">Background Gradient End</label>
                <div className="flex items-center gap-3">
                  <input
                    type="color"
                    name="heroBgGradientEnd"
                    value={form.heroBgGradientEnd || "#065f46"}
                    onChange={handleChange}
                    className="w-12 h-12 rounded cursor-pointer border-0 p-0"
                  />
                  <span className="text-sm font-mono text-slate-500">{form.heroBgGradientEnd}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* BESTSELLER CONFIG */}
        <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-amber-50 text-amber-600 rounded-lg">
                <ImageIcon className="w-5 h-5" />
              </div>
              <h2 className="text-lg font-bold text-slate-800">Featured Bestseller Product</h2>
            </div>
            
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-slate-700">Show Bestseller:</span>
              <button
                type="button"
                onClick={() => setForm({ ...form, bestsellerEnabled: !form.bestsellerEnabled })}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  form.bestsellerEnabled ? 'bg-emerald-500' : 'bg-slate-300'
                }`}
              >
                <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  form.bestsellerEnabled ? 'translate-x-6' : 'translate-x-1'
                }`} />
              </button>
            </div>
          </div>

          <div className={`transition-opacity ${!form.bestsellerEnabled ? 'opacity-50 pointer-events-none' : ''}`}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Bestseller Title</label>
                <input
                  type="text"
                  name="bestsellerTitle"
                  value={form.bestsellerTitle || ""}
                  onChange={handleChange}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Badge Subtitle</label>
                <input
                  type="text"
                  name="bestsellerSubtitle"
                  value={form.bestsellerSubtitle || ""}
                  onChange={handleChange}
                  placeholder="e.g. Bestseller"
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Product Image (Upload JPG/PNG)</label>
                <input
                  type="file"
                  accept="image/jpeg, image/jpg, image/png"
                  onChange={handleImageUpload}
                  className="w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-amber-100 file:text-amber-700 hover:file:bg-amber-200 cursor-pointer mb-3"
                />
                <div className="flex items-center gap-2 mb-3">
                  <div className="flex-1 border-t border-slate-200"></div>
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">OR</span>
                  <div className="flex-1 border-t border-slate-200"></div>
                </div>
                <input
                  type="text"
                  name="bestsellerImage"
                  value={form.bestsellerImage || ""}
                  onChange={handleChange}
                  placeholder="Enter Image URL directly"
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
            </div>

            <div className="flex items-center justify-center bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200 p-6">
              {form.bestsellerImage ? (
                <div className="relative w-full max-w-sm aspect-square rounded-3xl overflow-hidden shadow-xl border-4 border-white">
                  <img
                    src={form.bestsellerImage}
                    alt="Preview"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent"></div>
                  <div className="absolute bottom-6 left-6 right-6 p-4 bg-white/20 backdrop-blur-md rounded-2xl border border-white/30 text-white">
                    <p className="text-xs font-semibold uppercase tracking-widest text-amber-300">
                      {form.bestsellerSubtitle || "Bestseller"}
                    </p>
                    <p className="text-sm font-bold mt-0.5 line-clamp-1">{form.bestsellerTitle}</p>
                  </div>
                </div>
              ) : (
                <div className="text-slate-400 text-sm font-medium flex flex-col items-center">
                  <ImageIcon className="w-10 h-10 mb-2 opacity-50" />
                  No image preview available
                </div>
              )}
            </div>
          </div>
          </div>
        </div>

        {/* PROMO BANNER CONFIG */}
        <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
                <ImageIcon className="w-5 h-5" />
              </div>
              <h2 className="text-lg font-bold text-slate-800">Secondary Promotional Banner</h2>
            </div>
            
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-slate-700">Show Banner:</span>
              <button
                type="button"
                onClick={() => setForm({ ...form, promoBannerEnabled: !form.promoBannerEnabled })}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  form.promoBannerEnabled ? 'bg-emerald-500' : 'bg-slate-300'
                }`}
              >
                <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  form.promoBannerEnabled ? 'translate-x-6' : 'translate-x-1'
                }`} />
              </button>
            </div>
          </div>

          <div className={`transition-opacity ${!form.promoBannerEnabled ? 'opacity-50 pointer-events-none' : ''}`}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Banner Title</label>
                  <input
                    type="text"
                    name="promoBannerTitle"
                    value={form.promoBannerTitle || ""}
                    onChange={handleChange}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Banner Subtitle</label>
                  <input
                    type="text"
                    name="promoBannerSubtitle"
                    value={form.promoBannerSubtitle || ""}
                    onChange={handleChange}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Wide Banner Image (Upload JPG/PNG)</label>
                  <input
                    type="file"
                    accept="image/jpeg, image/jpg, image/png"
                    onChange={(e) => handleImageUpload(e, "promoBannerImage")}
                    className="w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-blue-100 file:text-blue-700 hover:file:bg-blue-200 cursor-pointer mb-3"
                  />
                  <div className="flex items-center gap-2 mb-3">
                    <div className="flex-1 border-t border-slate-200"></div>
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">OR</span>
                    <div className="flex-1 border-t border-slate-200"></div>
                  </div>
                  <input
                    type="text"
                    name="promoBannerImage"
                    value={form.promoBannerImage || ""}
                    onChange={handleChange}
                    placeholder="Enter Image URL directly"
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div className="flex flex-col justify-center bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200 p-6">
                <span className="text-xs font-bold text-slate-400 mb-3 text-center">Preview (Wide format)</span>
                {form.promoBannerImage ? (
                  <div className="relative w-full aspect-[21/9] rounded-2xl overflow-hidden shadow-lg border-2 border-white">
                    <img
                      src={form.promoBannerImage}
                      alt="Promo Preview"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-r from-slate-900/90 via-slate-900/50 to-transparent"></div>
                    <div className="absolute inset-y-0 left-0 p-6 flex flex-col justify-center text-white w-2/3">
                      <p className="text-xs font-bold text-blue-300 tracking-wider uppercase mb-1">{form.promoBannerSubtitle}</p>
                      <h3 className="text-lg font-extrabold leading-tight">{form.promoBannerTitle}</h3>
                    </div>
                  </div>
                ) : (
                  <div className="text-slate-400 text-sm font-medium flex flex-col items-center py-10">
                    <ImageIcon className="w-8 h-8 mb-2 opacity-50" />
                    No image preview available
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

      </form>
    </div>
  );
}
