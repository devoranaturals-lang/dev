"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { getProducts, getCategories, getOrders } from "../../lib/supabase";
import { Package, FolderTree, ShoppingBag, IndianRupee, Plus, ArrowRight } from "lucide-react";

export default function AdminOverviewPage() {
  const [stats, setStats] = useState({
    productsCount: 0,
    categoriesCount: 0,
    ordersCount: 0,
    totalRevenue: 0,
  });

  const [recentProducts, setRecentProducts] = useState([]);
  const [recentOrders, setRecentOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadMetrics() {
      try {
        setLoading(true);
        const [products, categories, orders] = await Promise.all([
          getProducts(),
          getCategories(),
          getOrders(),
        ]);

        const totalRev = (orders || []).reduce(
          (sum, o) => sum + Number(o.total_amount || 0),
          0
        );

        setStats({
          productsCount: (products || []).length,
          categoriesCount: (categories || []).length,
          ordersCount: (orders || []).length,
          totalRevenue: totalRev,
        });

        setRecentProducts((products || []).slice(0, 4));
        setRecentOrders((orders || []).slice(0, 4));
      } catch (err) {
        console.error("Dashboard error:", err);
      } finally {
        setLoading(false);
      }
    }
    loadMetrics();
  }, []);

  return (
    <div className="space-y-8">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900">Dashboard Overview</h1>
          <p className="text-xs text-slate-500 mt-1">Real-time stats from Supabase Database & Storefront</p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <Link
            href="/admin/categories"
            className="px-4 py-2.5 bg-emerald-50 hover:bg-emerald-100 text-brand-800 font-bold text-xs rounded-xl border border-brand-200 flex items-center gap-1.5 transition-colors"
          >
            <FolderTree className="w-4 h-4" />
            <span>Manage Categories</span>
          </Link>

          <Link
            href="/admin/products"
            className="px-4 py-2.5 bg-brand-800 hover:bg-brand-900 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-sm transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Add New Product</span>
          </Link>
        </div>
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-4 bg-emerald-50 text-emerald-700 rounded-2xl">
            <Package className="w-7 h-7" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Products</p>
            <h3 className="text-2xl font-black text-slate-900">{stats.productsCount}</h3>
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-4 bg-emerald-50 text-emerald-700 rounded-2xl">
            <FolderTree className="w-7 h-7" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Categories</p>
            <h3 className="text-2xl font-black text-slate-900">{stats.categoriesCount}</h3>
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-4 bg-amber-50 text-amber-700 rounded-2xl">
            <ShoppingBag className="w-7 h-7" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Customer Orders</p>
            <h3 className="text-2xl font-black text-slate-900">{stats.ordersCount}</h3>
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-4 bg-emerald-100 text-emerald-800 rounded-2xl">
            <IndianRupee className="w-7 h-7" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Revenue</p>
            <h3 className="text-2xl font-black text-emerald-700">₹{stats.totalRevenue.toLocaleString("en-IN")}</h3>
          </div>
        </div>
      </div>

      {/* Two Columns: Recent Products & Recent Orders */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Recent Products */}
        <div className="lg:col-span-6 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="font-bold text-slate-900 text-base">Recent Inventory Items</h3>
            <Link href="/admin/products" className="text-xs font-bold text-brand-700 flex items-center gap-1">
              <span>View All</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          <div className="space-y-3">
            {recentProducts.map((p) => (
              <div key={p.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-2xl">
                <div className="flex items-center gap-3">
                  <img
                    src={p.image_url || "https://images.unsplash.com/photo-1608248597263-00079e96047c?auto=format&fit=crop&w=100&q=80"}
                    alt={p.name}
                    className="w-10 h-10 object-cover rounded-xl border border-slate-200"
                  />
                  <div>
                    <p className="font-bold text-xs text-slate-800 leading-tight">{p.name}</p>
                    <p className="text-[10px] text-brand-700 font-semibold">{p.category}</p>
                  </div>
                </div>
                <span className="font-extrabold text-xs text-earth-700">
                  ₹{Number(p.price).toLocaleString("en-IN")}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Orders */}
        <div className="lg:col-span-6 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="font-bold text-slate-900 text-base">Recent Orders</h3>
            <Link href="/admin/orders" className="text-xs font-bold text-brand-700 flex items-center gap-1">
              <span>View All</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          {recentOrders.length === 0 ? (
            <p className="text-xs text-slate-400 py-6 text-center">No orders recorded yet.</p>
          ) : (
            <div className="space-y-3">
              {recentOrders.map((o) => (
                <div key={o.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-2xl text-xs">
                  <div>
                    <p className="font-bold text-slate-800">{o.customer_name}</p>
                    <p className="text-[10px] text-slate-400">{o.city}, {o.state}</p>
                  </div>
                  <div className="text-right">
                    <span className="font-bold text-slate-900 block">₹{Number(o.total_amount).toLocaleString("en-IN")}</span>
                    <span className="text-[10px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200">
                      {o.status || "Pending"}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
