"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { getProductById } from "../../../lib/supabase";
import { useCart } from "../../../context/CartContext";
import { ShoppingBag, Star, Check, ArrowLeft, Shield, Leaf, Truck } from "lucide-react";
import Link from "next/link";

export default function ProductDetailPage() {
  const { id } = useParams();
  const router = useRouter();
  const { addToCart } = useCart();
  
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(false);

  useEffect(() => {
    async function load() {
      if (!id) return;
      setLoading(true);
      const data = await getProductById(id);
      setProduct(data);
      setLoading(false);
    }
    load();
  }, [id]);

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <p className="text-slate-500 font-medium">Loading product details...</p>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center space-y-4">
        <h2 className="text-2xl font-bold text-slate-800">Product Not Found</h2>
        <p className="text-slate-500">The product you are looking for does not exist or has been removed.</p>
        <Link href="/products" className="inline-block px-6 py-2.5 bg-brand-800 text-white font-bold rounded-xl">
          Back to Products
        </Link>
      </div>
    );
  }

  const handleAddToCart = () => {
    addToCart(product, qty);
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  };

  const handleBuyNow = () => {
    addToCart(product, qty);
    router.push("/cart");
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
      <Link href="/products" className="inline-flex items-center gap-2 text-xs font-bold text-brand-800 hover:text-brand-900">
        <ArrowLeft className="w-4 h-4" />
        <span>Back to All Products</span>
      </Link>

      <div className="bg-white rounded-3xl p-6 sm:p-10 shadow-xl border border-slate-100 grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Product Image */}
        <div className="lg:col-span-6 relative aspect-square rounded-2xl overflow-hidden bg-slate-50 border border-slate-100">
          <img
            src={product.image_url || "https://images.unsplash.com/photo-1608248597263-00079e96047c?auto=format&fit=crop&w=800&q=80"}
            alt={product.name}
            className="w-full h-full object-cover"
          />
        </div>

        {/* Product Details */}
        <div className="lg:col-span-6 flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            <span className="px-3.5 py-1 bg-brand-50 text-brand-800 text-xs font-bold rounded-full border border-brand-200 inline-block">
              {product.category}
            </span>

            <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900">{product.name}</h1>

            <div className="flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <span className="text-3xl font-black text-earth-700">₹{Number(product.price).toLocaleString("en-IN")}</span>
                {product.actual_price && Number(product.actual_price) > Number(product.price) && (
                  <span className="text-lg font-semibold text-slate-400 line-through">
                    ₹{Number(product.actual_price).toLocaleString("en-IN")}
                  </span>
                )}
                {product.actual_price && Number(product.actual_price) > Number(product.price) && (
                  <span className="bg-red-100 text-red-600 text-xs font-bold px-2.5 py-1 rounded-md">
                    {Math.round(((Number(product.actual_price) - Number(product.price)) / Number(product.actual_price)) * 100)}% OFF
                  </span>
                )}
              </div>
              
              {product.rating && (
                <div className="flex items-center gap-1 bg-amber-50 text-amber-700 px-3 py-1 rounded-full text-xs font-bold border border-amber-200 w-fit">
                  <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                  <span>{product.rating} / 5.0</span>
                </div>
              )}
            </div>

            <p className="text-slate-600 text-sm leading-relaxed border-t border-slate-100 pt-4">
              {product.description}
            </p>
          </div>

          {/* Actions */}
          <div className="space-y-4 border-t border-slate-100 pt-6">
            <div className="flex items-center gap-4">
              <label className="text-xs font-bold text-slate-700">Quantity:</label>
              <div className="flex items-center border border-slate-200 rounded-xl overflow-hidden bg-slate-50">
                <button
                  onClick={() => setQty(Math.max(1, qty - 1))}
                  className="px-3.5 py-1.5 text-slate-600 hover:bg-slate-200 font-bold"
                >
                  -
                </button>
                <span className="px-4 text-sm font-bold text-slate-800">{qty}</span>
                <button
                  onClick={() => setQty(qty + 1)}
                  className="px-3.5 py-1.5 text-slate-600 hover:bg-slate-200 font-bold"
                >
                  +
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <button
                onClick={handleAddToCart}
                className={`py-3.5 px-6 rounded-2xl font-bold text-sm transition-all flex items-center justify-center gap-2 ${
                  added
                    ? "bg-emerald-600 text-white"
                    : "bg-brand-50 hover:bg-brand-100 text-brand-800 border border-brand-300"
                }`}
              >
                {added ? <Check className="w-5 h-5" /> : <ShoppingBag className="w-5 h-5" />}
                <span>{added ? "Added to Cart!" : "Add to Cart"}</span>
              </button>

              <button
                onClick={handleBuyNow}
                className="py-3.5 px-6 bg-brand-800 hover:bg-brand-900 text-white font-bold text-sm rounded-2xl transition-all shadow-lg shadow-brand-800/20"
              >
                Buy Now
              </button>
            </div>

            <div className="grid grid-cols-3 gap-4 pt-4 border-t border-slate-100 text-center text-[11px] text-slate-500">
              <div className="p-2 space-y-1">
                <Leaf className="w-5 h-5 mx-auto text-brand-700" />
                <p className="font-semibold">100% Herbal</p>
              </div>
              <div className="p-2 space-y-1">
                <Shield className="w-5 h-5 mx-auto text-brand-700" />
                <p className="font-semibold">Quality Assured</p>
              </div>
              <div className="p-2 space-y-1">
                <Truck className="w-5 h-5 mx-auto text-brand-700" />
                <p className="font-semibold">Fast Shipping</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
