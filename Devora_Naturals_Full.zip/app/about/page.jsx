import { Leaf, Sparkles, HeartHandshake, ShieldCheck } from "lucide-react";
import Link from "next/link";

export default function AboutPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-16">
      {/* Hero Banner */}
      <div className="bg-gradient-to-r from-brand-900 via-brand-800 to-brand-900 text-white rounded-3xl p-8 sm:p-16 shadow-2xl relative overflow-hidden text-center max-w-4xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-brand-700/60 text-brand-200 text-xs font-semibold">
          <Leaf className="w-4 h-4 text-emerald-300" />
          <span>Our Ayurvedic Heritage</span>
        </div>
        <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight">Rooted in Nature, Crafted with Care</h1>
        <p className="text-brand-100 text-base sm:text-lg leading-relaxed max-w-2xl mx-auto font-light">
          Devora Naturals brings ancient botanical wisdom to modern self-care routines. Every bottle is lovingly formulated using wild-harvested herbs and traditional cold-press extraction.
        </p>
      </div>

      {/* Pillars */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm space-y-3">
          <div className="p-3 bg-brand-50 text-brand-800 rounded-2xl w-fit">
            <Sparkles className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold text-slate-800">100% Pure Botanical Ingredients</h3>
          <p className="text-slate-500 text-sm leading-relaxed">
            We source our Kashmiri saffron, Bhringraj leaves, and Kannauj roses directly from certified organic farms without artificial preservatives.
          </p>
        </div>

        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm space-y-3">
          <div className="p-3 bg-brand-50 text-brand-800 rounded-2xl w-fit">
            <HeartHandshake className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold text-slate-800">Traditional Small-Batch Formulations</h3>
          <p className="text-slate-500 text-sm leading-relaxed">
            Following time-tested Ayurvedic taila-paka methods, our oils are slow-infused over copper vessels to preserve essential nutrients.
          </p>
        </div>

        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm space-y-3">
          <div className="p-3 bg-brand-50 text-brand-800 rounded-2xl w-fit">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold text-slate-800">Ethical & Eco-Friendly Packaging</h3>
          <p className="text-slate-500 text-sm leading-relaxed">
            All our products are cruelty-free, packaged in recyclable dark amber glass bottles to prevent UV oxidation.
          </p>
        </div>
      </div>

      <div className="text-center pt-6">
        <Link href="/products" className="px-8 py-4 bg-brand-800 text-white font-bold rounded-2xl shadow-lg">
          Explore Our Catalog
        </Link>
      </div>
    </div>
  );
}
