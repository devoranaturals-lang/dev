"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { getProducts, getCategories, getStorefrontSettings } from "../lib/supabase";
import ProductCard from "../components/ProductCard";
import { Search, Sparkles, ShieldCheck, Truck, HeartHandshake, Leaf, ArrowRight, RefreshCw } from "lucide-react";

export default function HomePage() {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [storefront, setStorefront] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      try {
        setLoading(true);
        const [prods, cats, sf] = await Promise.all([getProducts(), getCategories(), getStorefrontSettings()]);
        setProducts(prods || []);
        setCategories(cats || []);
        setStorefront(sf || null);
      } catch (err) {
        console.error("Failed to load storefront data:", err);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  const activeProducts = products.filter(p => p.is_active !== false);

  const filteredProducts = activeProducts.filter((product) => {
    const matchesCategory =
      selectedCategory === "All" ||
      product.category?.toLowerCase() === selectedCategory.toLowerCase();
    const matchesSearch =
      product.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description?.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="space-y-16 pb-16">
      {/* HERO SECTION */}
      <section 
        className="relative overflow-hidden text-white pt-16 pb-24 px-4 sm:px-6 lg:px-8"
        style={storefront ? { background: `linear-gradient(to bottom, ${storefront.heroBgGradientStart}, ${storefront.heroBgGradientEnd})` } : { background: `linear-gradient(to bottom, #064e3b, #065f46)` }}
      >
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#86efac_1px,transparent_1px)] [background-size:16px_16px]"></div>
        
        <div className="max-w-7xl mx-auto relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className={storefront?.bestsellerEnabled === false ? "lg:col-span-12 space-y-6 text-center" : "lg:col-span-7 space-y-6 text-center lg:text-left"}>
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-brand-700/60 border border-brand-500/40 text-brand-200 text-xs font-semibold backdrop-blur-md">
              <Sparkles className="w-4 h-4 text-earth-300" />
              <span>Pure Organic & Ayurvedic Wellness</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-tight whitespace-pre-wrap">
              {storefront?.heroHeading || (
                <>
                  Natural Care For Your <br className="hidden sm:inline" />
                  <span className="bg-gradient-to-r from-earth-200 via-amber-200 to-emerald-200 bg-clip-text text-transparent">
                    Skin, Hair & Soul
                  </span>
                </>
              )}
            </h1>

            <p className={`text-base sm:text-lg text-brand-100 leading-relaxed font-light ${storefront?.bestsellerEnabled === false ? "max-w-3xl mx-auto" : "max-w-2xl mx-auto lg:mx-0"}`}>
              {storefront?.heroDescription || "Elevate your daily self-care ritual with handcrafted Kumkumadi oils, wild-harvested Bhringraj scalp tonics, and sacred organic Sambrani dhoop."}
            </p>

            <div className={`flex flex-wrap items-center gap-4 pt-2 ${storefront?.bestsellerEnabled === false ? "justify-center" : "justify-center lg:justify-start"}`}>
              <a
                href="#products-section"
                className="px-8 py-4 bg-earth-600 hover:bg-earth-700 text-white font-bold rounded-2xl transition-all shadow-lg hover:shadow-earth-600/30 flex items-center gap-2 text-base"
              >
                <span>Explore Catalog</span>
                <ArrowRight className="w-5 h-5" />
              </a>

              <Link
                href="/about"
                className="px-8 py-4 bg-brand-800/80 hover:bg-brand-800 text-brand-100 font-semibold rounded-2xl transition-colors border border-brand-700 text-base"
              >
                Our Botanical Story
              </Link>
            </div>
          </div>

          {storefront?.bestsellerEnabled !== false && (
            <div className="lg:col-span-5 relative flex justify-center">
              <div className="relative w-full max-w-md aspect-square rounded-3xl overflow-hidden shadow-2xl border-4 border-brand-700/50 group">
                <img
                  src={storefront?.bestsellerImage || "https://images.unsplash.com/photo-1608248597263-00079e96047c?auto=format&fit=crop&w=800&q=80"}
                  alt={storefront?.bestsellerTitle || "Bestseller"}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent"></div>
                <div className="absolute bottom-6 left-6 right-6 p-4 bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 text-white">
                  <p className="text-xs font-semibold text-earth-300 uppercase tracking-widest">{storefront?.bestsellerSubtitle || "Bestseller"}</p>
                  <p className="text-sm font-bold mt-0.5 line-clamp-1">{storefront?.bestsellerTitle || "Kumkumadi Saffron Glow Oil"}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* VALUE PROPOSITIONS BANNER */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-12 relative z-20">
        <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-xl border border-slate-100 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
          <div className="flex items-center gap-4 p-3 rounded-2xl bg-emerald-50/50">
            <div className="p-3 bg-brand-800 text-brand-100 rounded-xl">
              <Leaf className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-slate-800">100% Organic</h4>
              <p className="text-xs text-slate-500">Pure herbal extracts</p>
            </div>
          </div>

          <div className="flex items-center gap-4 p-3 rounded-2xl bg-emerald-50/50">
            <div className="p-3 bg-brand-800 text-brand-100 rounded-xl">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-slate-800">Chemical Free</h4>
              <p className="text-xs text-slate-500">Zero parabens or sulfates</p>
            </div>
          </div>

          <div className="flex items-center gap-4 p-3 rounded-2xl bg-emerald-50/50">
            <div className="p-3 bg-brand-800 text-brand-100 rounded-xl">
              <HeartHandshake className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-slate-800">Handcrafted</h4>
              <p className="text-xs text-slate-500">Small batch perfection</p>
            </div>
          </div>

          <div className="flex items-center gap-4 p-3 rounded-2xl bg-emerald-50/50">
            <div className="p-3 bg-brand-800 text-brand-100 rounded-xl">
              <Truck className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-slate-800">Express Delivery</h4>
              <p className="text-xs text-slate-500">Safe Pan-India shipping</p>
            </div>
          </div>
        </div>
      </div>

      {/* SECONDARY PROMO BANNER */}
      {storefront?.promoBannerEnabled && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12 mb-8">
          <div className="relative w-full aspect-[21/9] md:aspect-[24/7] rounded-3xl overflow-hidden shadow-xl group">
            <img 
              src={storefront.promoBannerImage || "https://images.unsplash.com/photo-1615397323282-311ab261291b?auto=format&fit=crop&w=1200&h=400&q=80"}
              alt="Promo Banner"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-brand-900/90 via-brand-900/60 to-transparent"></div>
            <div className="absolute inset-y-0 left-0 p-8 sm:p-12 md:p-16 flex flex-col justify-center text-white max-w-2xl">
              <span className="text-xs sm:text-sm font-bold text-earth-300 uppercase tracking-widest mb-2 sm:mb-4">
                {storefront.promoBannerSubtitle}
              </span>
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold leading-tight mb-6">
                {storefront.promoBannerTitle}
              </h2>
              <a 
                href="#products-section"
                className="inline-flex w-fit items-center gap-2 px-6 py-3 bg-earth-600 hover:bg-earth-700 text-white font-bold rounded-xl transition-colors shadow-lg"
              >
                <span>Shop Now</span>
                <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      )}

      {/* PRODUCTS STOREFRONT CATALOG */}
      <section id="products-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 pt-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-slate-200 pb-6">
          <div>
            <span className="text-xs font-bold uppercase tracking-widest text-brand-700">Catalog Collection</span>
            <h2 className="text-3xl font-extrabold text-slate-900 mt-1">Our Natural Products</h2>
          </div>

          {/* Search Box */}
          <div className="relative w-full md:w-80">
            <Search className="w-5 h-5 absolute left-3.5 top-3 text-slate-400" />
            <input
              type="text"
              placeholder="Search products, ingredients..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-11 pr-4 py-2.5 bg-white border border-slate-200 rounded-2xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-700 shadow-sm"
            />
          </div>
        </div>

        {/* Dynamic Category Filter Pills */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setSelectedCategory("All")}
            className={`px-5 py-2.5 rounded-full text-xs font-bold transition-all shadow-sm ${
              selectedCategory === "All"
                ? "bg-brand-900 text-white shadow-brand-900/20"
                : "bg-white text-slate-600 hover:bg-emerald-50 border border-slate-200"
            }`}
          >
            All Products ({activeProducts.length})
          </button>

          {categories.map((cat) => (
            <button
              key={cat.id || cat.name}
              onClick={() => setSelectedCategory(cat.name)}
              className={`px-5 py-2.5 rounded-full text-xs font-bold transition-all shadow-sm ${
                selectedCategory.toLowerCase() === cat.name.toLowerCase()
                  ? "bg-brand-900 text-white shadow-brand-900/20"
                  : "bg-white text-slate-600 hover:bg-emerald-50 border border-slate-200"
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>

        {/* Products Grid */}
        {loading ? (
          <div className="py-20 text-center flex flex-col items-center justify-center space-y-3">
            <RefreshCw className="w-8 h-8 text-brand-700 animate-spin" />
            <p className="text-sm font-medium text-slate-500">Loading organic catalog...</p>
          </div>
        ) : filteredProducts.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center border border-slate-100 space-y-4">
            <p className="text-lg font-bold text-slate-700">No products found matching your search</p>
            <p className="text-sm text-slate-500">Try clearing your filters or search keywords.</p>
            <button
              onClick={() => {
                setSelectedCategory("All");
                setSearchQuery("");
              }}
              className="px-6 py-2.5 bg-brand-800 text-white text-xs font-bold rounded-xl"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-8">
            {filteredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
