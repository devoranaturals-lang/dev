"use client";

import { useState, useEffect } from "react";
import { Mail, Phone, MapPin, Send, CheckCircle2 } from "lucide-react";
import { getContactDetails } from "../../lib/supabase";

export default function ContactPage() {
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [contactDetails, setContactDetails] = useState({
    email: "support@devoranaturals.com",
    phone: "+91 (800) 456-7890",
    address: "Kerala Botanical Organic Farm, India"
  });

  useEffect(() => {
    async function loadSettings() {
      try {
        const data = await getContactDetails();
        if (data) setContactDetails(data);
      } catch (e) {
        console.error("Contact details fetch error:", e);
      }
    }
    loadSettings();
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-12">
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <h1 className="text-4xl font-extrabold text-slate-900">Get in Touch</h1>
        <p className="text-slate-500 text-sm">
          Have questions about our botanical hair oils or sacred pooja items? We are here to assist you.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Contact Info */}
        <div className="lg:col-span-5 bg-brand-900 text-white p-8 rounded-3xl space-y-8 shadow-xl">
          <h2 className="text-2xl font-bold">Contact Information</h2>

          <div className="space-y-6 text-sm">
            <div className="flex items-start gap-4">
              <div className="p-2.5 bg-brand-800 rounded-xl text-brand-200">
                <Mail className="w-5 h-5" />
              </div>
              <div>
                <p className="font-semibold text-xs text-brand-300 uppercase">Email Support</p>
                <p className="font-bold text-white">{contactDetails.email}</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="p-2.5 bg-brand-800 rounded-xl text-brand-200">
                <Phone className="w-5 h-5" />
              </div>
              <div>
                <p className="font-semibold text-xs text-brand-300 uppercase">Customer Care</p>
                <p className="font-bold text-white">{contactDetails.phone}</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="p-2.5 bg-brand-800 rounded-xl text-brand-200">
                <MapPin className="w-5 h-5" />
              </div>
              <div>
                <p className="font-semibold text-xs text-brand-300 uppercase">Botanical Headquarters</p>
                <p className="font-bold text-white">{contactDetails.address}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Contact Form */}
        <div className="lg:col-span-7 bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
          {submitted ? (
            <div className="py-16 text-center space-y-4">
              <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto" />
              <h3 className="text-2xl font-bold text-slate-800">Message Sent!</h3>
              <p className="text-slate-500 text-sm">Thank you for reaching out. Our customer care team will respond within 24 hours.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Your Name</label>
                <input
                  type="text"
                  required
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="Full Name"
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-700"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  placeholder="Email"
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-700"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Message</label>
                <textarea
                  rows={4}
                  required
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  placeholder="How can we assist you?"
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-700"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3.5 bg-brand-800 hover:bg-brand-900 text-white font-bold text-sm rounded-xl transition-all shadow-md flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" />
                <span>Send Message</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
