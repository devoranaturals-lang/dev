"use client";

import Link from "next/link";
import { useCart } from "../../context/CartContext";
import { Trash2, ShoppingBag, ArrowRight, ArrowLeft } from "lucide-react";

export default function CartPage() {
  const { cart, removeFromCart, updateQuantity, clearCart, cartTotal } = useCart();

  if (cart.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center space-y-6">
        <div className="w-20 h-20 bg-brand-50 text-brand-800 rounded-full flex items-center justify-center mx-auto shadow-inner">
          <ShoppingBag className="w-10 h-10" />
        </div>
        <h2 className="text-3xl font-extrabold text-slate-800">Your Shopping Cart is Empty</h2>
        <p className="text-slate-500 max-w-md mx-auto">
          Explore our organic herbal skincare, Ayurvedic hair elixirs, and sacred incense products to add items to your cart.
        </p>
        <Link
          href="/products"
          className="inline-flex items-center gap-2 px-8 py-3.5 bg-brand-800 hover:bg-brand-900 text-white font-bold text-sm rounded-2xl transition-all shadow-lg shadow-brand-800/20"
        >
          <span>Explore Products</span>
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
      <div className="flex items-center justify-between border-b border-slate-200 pb-6">
        <h1 className="text-3xl font-extrabold text-slate-900">Your Shopping Cart</h1>
        <button
          onClick={clearCart}
          className="text-xs font-bold text-red-600 hover:text-red-800 transition-colors"
        >
          Clear Cart
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Cart Item List */}
        <div className="lg:col-span-8 space-y-4">
          {cart.map((item) => (
            <div
              key={item.id}
              className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-6"
            >
              <div className="flex items-center gap-4 w-full sm:w-auto">
                <img
                  src={item.image_url || "https://images.unsplash.com/photo-1608248597263-00079e96047c?auto=format&fit=crop&w=200&q=80"}
                  alt={item.name}
                  className="w-20 h-20 object-cover rounded-xl border border-slate-100 flex-shrink-0"
                />
                <div>
                  <h3 className="font-bold text-slate-800 text-base leading-snug">{item.name}</h3>
                  <p className="text-xs text-brand-700 font-semibold mt-0.5">{item.category}</p>
                  <p className="text-sm font-bold text-earth-700 mt-1">₹{Number(item.price).toLocaleString("en-IN")}</p>
                </div>
              </div>

              {/* Quantity Controls & Remove */}
              <div className="flex items-center justify-between sm:justify-end gap-6 w-full sm:w-auto border-t sm:border-t-0 border-slate-100 pt-4 sm:pt-0">
                <div className="flex items-center border border-slate-200 rounded-xl bg-slate-50 overflow-hidden">
                  <button
                    onClick={() => updateQuantity(item.id, -1)}
                    className="px-3 py-1 font-bold text-slate-600 hover:bg-slate-200 text-sm"
                  >
                    -
                  </button>
                  <span className="px-3 font-bold text-slate-800 text-sm">{item.quantity}</span>
                  <button
                    onClick={() => updateQuantity(item.id, 1)}
                    className="px-3 py-1 font-bold text-slate-600 hover:bg-slate-200 text-sm"
                  >
                    +
                  </button>
                </div>

                <span className="font-extrabold text-slate-900 text-base min-w-[80px] text-right">
                  ₹{(Number(item.price) * item.quantity).toLocaleString("en-IN")}
                </span>

                <button
                  onClick={() => removeFromCart(item.id)}
                  className="p-2 text-slate-400 hover:text-red-600 transition-colors"
                  title="Remove Item"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            </div>
          ))}

          <Link
            href="/products"
            className="inline-flex items-center gap-2 text-xs font-bold text-brand-800 hover:text-brand-900 pt-2"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Continue Shopping</span>
          </Link>
        </div>

        {/* Order Summary Side Card */}
        <div className="lg:col-span-4">
          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-xl space-y-6 sticky top-28">
            <h2 className="text-xl font-extrabold text-slate-900 border-b border-slate-100 pb-4">
              Order Summary
            </h2>

            <div className="space-y-3 text-sm">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal ({cart.length} items)</span>
                <span className="font-bold text-slate-800">₹{cartTotal.toLocaleString("en-IN")}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Estimated Shipping</span>
                <span className="font-bold text-emerald-600">FREE</span>
              </div>
              <div className="border-t border-slate-100 pt-3 flex justify-between text-lg font-black text-slate-900">
                <span>Total Amount</span>
                <span className="text-earth-700">₹{cartTotal.toLocaleString("en-IN")}</span>
              </div>
            </div>

            <Link
              href="/checkout"
              className="w-full py-4 bg-brand-800 hover:bg-brand-900 text-white font-bold text-center text-sm rounded-2xl transition-all shadow-lg shadow-brand-800/20 flex items-center justify-center gap-2"
            >
              <span>Proceed to Checkout</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
