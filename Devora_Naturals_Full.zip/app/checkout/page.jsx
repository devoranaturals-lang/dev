"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useCart } from "../../context/CartContext";
import { createOrder, getContactDetails, getOffers } from "../../lib/supabase";
import { CheckCircle2, ShoppingBag, ShieldCheck, Tag, X } from "lucide-react";
import Link from "next/link";

export default function CheckoutPage() {
  const router = useRouter();
  const { cart, cartTotal, clearCart } = useCart();

  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    address: "",
    city: "",
    state: "",
    pincode: "",
  });

  const [loading, setLoading] = useState(false);
  const [orderSuccess, setOrderSuccess] = useState(null);
  const [errorMsg, setErrorMsg] = useState("");
  const [whatsappNumber, setWhatsappNumber] = useState("8608540400");

  const [couponCode, setCouponCode] = useState("");
  const [appliedCoupon, setAppliedCoupon] = useState(null);
  const [couponError, setCouponError] = useState("");
  const [discountAmount, setDiscountAmount] = useState(0);
  const [offers, setOffers] = useState([]);

  useEffect(() => {
    async function loadData() {
      try {
        const [contact, fetchedOffers] = await Promise.all([getContactDetails(), getOffers()]);
        if (contact && contact.whatsapp) {
          setWhatsappNumber(contact.whatsapp);
        }
        if (fetchedOffers) {
          setOffers(fetchedOffers);
        }
      } catch (e) {
        console.error("Failed to fetch initial data:", e);
      }
    }
    loadData();
  }, []);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleApplyCoupon = () => {
    setCouponError("");
    if (!couponCode.trim()) return;

    const validOffer = offers.find(
      (o) => o.isActive && o.discountCode && o.discountCode.toUpperCase() === couponCode.toUpperCase()
    );

    if (validOffer) {
      setAppliedCoupon(validOffer);
      const discount = Math.round(cartTotal * 0.1); // Fixed 10% discount for coupons
      setDiscountAmount(discount);
    } else {
      setCouponError("Invalid or expired coupon code.");
    }
  };

  const handleRemoveCoupon = () => {
    setAppliedCoupon(null);
    setDiscountAmount(0);
    setCouponCode("");
  };

  const handleSubmitOrder = async (e) => {
    e.preventDefault();
    if (!formData.name || !formData.phone || !formData.address || !formData.city || !formData.pincode) {
      setErrorMsg("Please fill in all required customer details.");
      return;
    }

    try {
      setLoading(true);
      setErrorMsg("");

      const finalTotal = cartTotal - discountAmount;
      const orderData = {
        ...formData,
        totalAmount: finalTotal,
      };

      const created = await createOrder(orderData, cart);
      
      // Generate WhatsApp message
      const itemsList = cart.map(item => `${item.name} (x${item.quantity})`).join(", ");
      const message = `Hello! I would like to place a new order.

*Order ID:* ${created.id}
*Name:* ${formData.name}
*Phone:* ${formData.phone}
*Address:* ${formData.address}, ${formData.city}, ${formData.state} - ${formData.pincode}

*Items:*
${itemsList}

${appliedCoupon ? `*Coupon Applied:* ${appliedCoupon.discountCode} (-₹${discountAmount})\n` : ""}*Total Amount:* ₹${finalTotal.toLocaleString("en-IN")}

Please confirm my order. Thank you!`;

      const encodedMessage = encodeURIComponent(message);
      const waUrl = `https://wa.me/${whatsappNumber}?text=${encodedMessage}`;
      
      window.open(waUrl, '_blank');
      
      setOrderSuccess(created);
      clearCart();
    } catch (err) {
      console.error("Order submission failed:", err);
      setErrorMsg(err.message || "Failed to place order. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  if (orderSuccess) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center space-y-6">
        <div className="w-20 h-20 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto shadow-inner">
          <CheckCircle2 className="w-12 h-12" />
        </div>
        <h1 className="text-3xl font-extrabold text-slate-900">Order Placed Successfully!</h1>
        <p className="text-slate-600 text-sm max-w-md mx-auto leading-relaxed">
          Thank you, <span className="font-bold text-slate-800">{orderSuccess.customer_name}</span>. Your order reference ID is{" "}
          <span className="font-mono font-bold text-brand-800">{orderSuccess.id}</span>. We are preparing your organic natural products for delivery.
        </p>
        <Link
          href="/"
          className="inline-block px-8 py-3.5 bg-brand-800 hover:bg-brand-900 text-white font-bold text-sm rounded-2xl transition-all shadow-lg"
        >
          Return to Homepage
        </Link>
      </div>
    );
  }

  if (cart.length === 0) {
    return (
      <div className="max-w-xl mx-auto px-4 py-20 text-center space-y-4">
        <h2 className="text-2xl font-bold text-slate-800">Your Cart is Empty</h2>
        <p className="text-slate-500 text-sm">Please add items to your cart before proceeding to checkout.</p>
        <Link href="/products" className="inline-block px-6 py-2.5 bg-brand-800 text-white font-bold rounded-xl text-xs">
          View Products
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
      <div className="border-b border-slate-200 pb-6">
        <h1 className="text-3xl font-extrabold text-slate-900">Order Checkout</h1>
        <p className="text-slate-500 text-sm mt-1">Fill in your shipping details to complete your order.</p>
      </div>

      {errorMsg && (
        <div className="p-4 bg-red-50 border border-red-200 text-red-700 text-sm font-semibold rounded-2xl">
          {errorMsg}
        </div>
      )}

      <form onSubmit={handleSubmitOrder} className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Customer Address Form */}
        <div className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm space-y-6">
          <h2 className="text-xl font-bold text-slate-900 border-b border-slate-100 pb-4">
            Shipping Information
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Full Name *</label>
              <input
                type="text"
                name="name"
                required
                value={formData.name}
                onChange={handleChange}
                placeholder="e.g. Ananya Sharma"
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-700"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Mobile Number *</label>
              <input
                type="text"
                name="phone"
                required
                value={formData.phone}
                onChange={handleChange}
                placeholder="10-digit mobile number"
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-700"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Email Address</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="For order tracking updates"
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-700"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Delivery Address *</label>
            <textarea
              name="address"
              required
              rows={3}
              value={formData.address}
              onChange={handleChange}
              placeholder="House/Flat No., Street, Landmark"
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-700"
            />
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">City *</label>
              <input
                type="text"
                name="city"
                required
                value={formData.city}
                onChange={handleChange}
                placeholder="City"
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-700"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">State *</label>
              <input
                type="text"
                name="state"
                required
                value={formData.state}
                onChange={handleChange}
                placeholder="State"
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-700"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Pincode *</label>
              <input
                type="text"
                name="pincode"
                required
                value={formData.pincode}
                onChange={handleChange}
                placeholder="6-digit PIN"
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-700"
              />
            </div>
          </div>
        </div>

        {/* Order Summary & Submit Button */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-xl space-y-6 sticky top-28">
            <h2 className="text-xl font-bold text-slate-900 border-b border-slate-100 pb-4 flex items-center justify-between">
              <span>Order Items ({cart.length})</span>
              <ShoppingBag className="w-5 h-5 text-brand-800" />
            </h2>

            <div className="space-y-3 max-h-60 overflow-y-auto pr-2">
              {cart.map((item) => (
                <div key={item.id} className="flex justify-between items-center text-xs">
                  <div>
                    <p className="font-bold text-slate-800">{item.name}</p>
                    <p className="text-slate-500">Qty: {item.quantity}</p>
                  </div>
                  <span className="font-bold text-slate-900">
                    ₹{(Number(item.price) * item.quantity).toLocaleString("en-IN")}
                  </span>
                </div>
              ))}
            </div>

            <div className="border-t border-slate-100 pt-4 pb-4">
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Enter Coupon Code"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                  disabled={appliedCoupon !== null}
                  className="flex-1 px-4 py-2 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-brand-700 outline-none disabled:bg-slate-100"
                />
                {!appliedCoupon ? (
                  <button
                    type="button"
                    onClick={handleApplyCoupon}
                    className="px-4 py-2 bg-slate-800 text-white text-sm font-bold rounded-xl hover:bg-slate-900 transition-colors"
                  >
                    Apply
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={handleRemoveCoupon}
                    className="px-4 py-2 bg-red-100 text-red-600 hover:bg-red-200 text-sm font-bold rounded-xl transition-colors"
                  >
                    Remove
                  </button>
                )}
              </div>
              {couponError && <p className="text-red-500 text-xs font-semibold mt-2">{couponError}</p>}
              {appliedCoupon && (
                <p className="text-emerald-600 text-xs font-semibold mt-2 flex items-center gap-1">
                  <Tag className="w-3.5 h-3.5" /> Coupon "{appliedCoupon.discountCode}" applied! (10% OFF)
                </p>
              )}
            </div>

            <div className="border-t border-slate-100 pt-4 space-y-2 text-sm">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal</span>
                <span>₹{cartTotal.toLocaleString("en-IN")}</span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between text-emerald-600 font-medium">
                  <span>Discount</span>
                  <span>-₹{discountAmount.toLocaleString("en-IN")}</span>
                </div>
              )}
              <div className="flex justify-between text-slate-600">
                <span>Shipping</span>
                <span className="font-bold text-emerald-600">FREE</span>
              </div>
              <div className="flex justify-between text-lg font-black text-slate-900 pt-1 border-t border-slate-100">
                <span>Total Payable</span>
                <span className="text-earth-700">₹{(cartTotal - discountAmount).toLocaleString("en-IN")}</span>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-4 bg-brand-800 hover:bg-brand-900 disabled:opacity-50 text-white font-bold text-center text-sm rounded-2xl transition-all shadow-lg shadow-brand-800/20 flex items-center justify-center gap-2"
            >
              <ShieldCheck className="w-5 h-5" />
              <span>{loading ? "Placing Order..." : "Place Order"}</span>
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}
