"use client";
import { useState, useEffect } from "react";
import Link from "next/link";
import { Leaf, Heart, Mail, Phone, MapPin } from "lucide-react";
import { usePathname } from "next/navigation";
import { getContactDetails } from "../lib/supabase";

export default function Footer() {
  const pathname = usePathname();
  const [contactDetails, setContactDetails] = useState({
    email: "support@devoranaturals.com",
    phone: "+91 (800) 456-7890",
    address: "Kerala Botanical Organic Farm, India"
  });

  useEffect(() => {
    async function loadSettings() {
      try {
        const data = await getContactDetails();
        if (data) setContactDetails(data);
      } catch (e) {
        console.error("Footer fetch error:", e);
      }
    }
    loadSettings();
  }, []);

  if (pathname?.startsWith("/admin")) {
    return null;
  }

  return (
    <footer className="bg-brand-900 text-brand-100 border-t border-brand-800 pt-16 pb-12 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
          {/* Brand Info Column */}
          <div className="space-y-4 md:col-span-1">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-brand-700 rounded-lg">
                <Leaf className="w-5 h-5 text-brand-200" />
              </div>
              <span className="text-xl font-bold text-white">Devora Naturals</span>
            </div>
            <p className="text-sm text-brand-200/80 leading-relaxed">
              Crafting pure, organic herbal products deeply rooted in Ayurvedic heritage. Dedicated to your wellness, radiant skin, and authentic traditional rituals.
            </p>
          </div>

          {/* Quick Links Column */}
          <div className="space-y-3">
            <h4 className="text-white font-semibold text-base uppercase tracking-wider text-xs">Categories</h4>
            <ul className="space-y-2 text-sm text-brand-200/80">
              <li>
                <Link href="/products?category=Skin Care" className="hover:text-earth-200 transition-colors">
                  Skin Care Essentials
                </Link>
              </li>
              <li>
                <Link href="/products?category=Hair Care" className="hover:text-earth-200 transition-colors">
                  Ayurvedic Hair Oils
                </Link>
              </li>
              <li>
                <Link href="/products?category=Pooja Items" className="hover:text-earth-200 transition-colors">
                  Sacred Pooja Dhoop & Resins
                </Link>
              </li>
              <li>
                <Link href="/products" className="hover:text-earth-200 transition-colors">
                  View Full Catalog
                </Link>
              </li>
            </ul>
          </div>

          {/* Company Column */}
          <div className="space-y-3">
            <h4 className="text-white font-semibold text-base uppercase tracking-wider text-xs">Devora Naturals</h4>
            <ul className="space-y-2 text-sm text-brand-200/80">
              <li>
                <Link href="/about" className="hover:text-earth-200 transition-colors">
                  About Our Brand
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-earth-200 transition-colors">
                  Contact & Support
                </Link>
              </li>
              <li>
                <Link href="/account" className="hover:text-earth-200 transition-colors text-xs text-brand-300">
                  Customer Account
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Column */}
          <div className="space-y-3">
            <h4 className="text-white font-semibold text-base uppercase tracking-wider text-xs">Contact Us</h4>
            <ul className="space-y-2 text-sm text-brand-200/80">
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-earth-300" />
                <span>{contactDetails.email}</span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-earth-300" />
                <span>{contactDetails.phone}</span>
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-earth-300" />
                <span>{contactDetails.address}</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-brand-800/60 flex flex-col sm:flex-row items-center justify-between text-xs text-brand-300 gap-4">
          <p>© {new Date().getFullYear()} Devora Naturals. All Rights Reserved.</p>
          <p className="flex items-center gap-1">
            <span>Handcrafted with</span>
            <Heart className="w-3.5 h-3.5 text-red-400 fill-current" />
            <span>for natural wellness</span>
          </p>
        </div>
      </div>
    </footer>
  );
}
